const button = document.getElementById('surpriseBtn');
const surprise = document.getElementById('surprise');
button.addEventListener('click', () => {
  const opening = surprise.hidden;
  surprise.hidden = !opening;
  button.innerHTML = opening ? 'Relire mon petit mot <span>♡</span>' : 'Ouvrir mon dernier petit mot <span>♡</span>';
  if (opening) surprise.scrollIntoView({ behavior: 'smooth', block: 'center' });
});
